-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 14-12-2011 a las 09:38:03
-- Versión del servidor: 5.1.54
-- Versión de PHP: 5.3.5-1ubuntu7.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `hibernate1`
--
CREATE DATABASE `hibernate1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hibernate1`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hibernate_unique_key`
--

CREATE TABLE IF NOT EXISTS `hibernate_unique_key` (
  `next_hi` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `hibernate_unique_key`
--

INSERT INTO `hibernate_unique_key` (`next_hi`) VALUES
(5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libro`
--

CREATE TABLE IF NOT EXISTS `libro` (
  `id` int(11) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `fechaPublicacion` date NOT NULL,
  `precio` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `libro`
--

INSERT INTO `libro` (`id`, `titulo`, `fechaPublicacion`, `precio`) VALUES
(32768, 'titulo1', '2007-03-23', 10.27),
(65536, 'titulo1', '2007-03-23', 10.27),
(98304, 'titulo1', '2007-03-23', 10.27),
(131072, 'titulo1', '2007-03-23', 10.27);
